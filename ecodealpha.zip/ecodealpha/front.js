// fetch('/products')
//     .then(response => {
//         if (!response.ok) {
//             throw new Error('Error fetching products');
//         }
//         return response.json();
//     })
//     .then(products => {
//         // Display the products on the frontend
//         const productContainer = document.getElementById('products');
//         productContainer.innerHTML = '';
//         products.forEach(product => {
//             const productHTML = `
//                 <div>
//                     <h2>${product.name}</h2>
//                     <p>Price: ${product.price}</p>
//                     <p>${product.description}</p>
//                 </div>
//             `;
//             productContainer.innerHTML += productHTML;
//         });
//     })
//     .catch(error => console.error('Error fetching products:', error));

// Add a new product to the backend
// const addProductForm = document.getElementById('add-product-form');
// addProductForm.addEventListener('submit', async (event) => {
//     event.preventDefault();
//     const productName = document.getElementById('product-name').value;
//     const productPrice = document.getElementById('product-price').value;
//     const productDescription = document.getElementById('product-description').value;
//     try {
//         const response = await fetch('/products', {
//             method: 'POST',
//             headers: { 'Content-Type': 'application/json' },
//             body: JSON.stringify({ name: productName, price: productPrice, description: productDescription })
//         });
//         if (!response.ok) {
//             throw new Error('Error adding product');
//         }
//         const product = await response.json();
//         console.log('Product added successfully:', product);
//         // Refresh the products list
//         fetch('/products')
//             .then(response => response.json())
//             .then(products => {
//                 const productContainer = document.getElementById('products');
//                 productContainer.innerHTML = '';
//                 products.forEach(product => {
//                     const productHTML = `
//                         <div>
//                             <h2>${product.name}</h2>
//                             <p>Price: ${product.price}</p>
//                             <p>${product.description}</p>
//                         </div>
//                     `;
//                     productContainer.innerHTML += productHTML;
//                 });
//             })
//             .catch(error => console.error('Error fetching products:', error));
//     } catch (error) {
//         console.error('Error adding product:', error);
//     }
// });













// Get all products from the backend
fetch('/products')
    .then(response => {
        if (!response.ok) {
            throw new Error('Error fetching products');
        }
        return response.json();
    })
    .then(products => {
        // Display the products on the frontend
        const productContainer = document.getElementById('products');
        productContainer.innerHTML = '';
        products.forEach(product => {
            const productHTML = `
                <div class="product" data-id="${product._id}">
                    <h3 class="description">${product.name}</h3>
                    <p class="description">Price: $${product.price}</p>
                    <p class="description">${product.description}</p>
                    <h2>Perfume Order Form</h2>
                    <form id="orderForm" action="/placeOrder" method="post">
                        <!-- Product Information -->
                        <label for="product">Select Perfume:</label>
                        <select id="product" name="product" required>
                            <option value="Floral Elegance">Floral Elegance</option>
                            <option value="Warm & Woody">Warm & Woody</option>
                            <option value="Oriental Opulence">Oriental Opulence</option>
                        </select>
                    </form>
                    <div id="orderContainer">
                        <h2>Choose the Price</h2>
                        <div>
                            <input type="radio" id="item30" name="Price" value="30">
                            <label for="item30">$30</label>
                        </div>
                        <div>
                            <input type="radio" id="item120" name="Price" value="120">
                            <label for="item120">$120</label>
                        </div>
                        <button id="add-to-cart">Purchase</button>
                    </div>
                </div>
            `;
            productContainer.innerHTML += productHTML;
        });
    })
    .catch(error => console.error('Error fetching products:', error));

// Add event listener to the add-to-cart button
document.addEventListener('click', function(event) {
    if (event.target.id === 'add-to-cart') {
        const selectedItem = document.querySelector('input[name="Price"]:checked');
        if (selectedItem) {
            const price = selectedItem.value;
            alert(`You have purchased the item for $${price}`);
        } else {
            alert("Please select an item to purchase.");
        }
    }
});

// Add event listener to the second button
document.addEventListener('click', function(event) {
    if (event.target.id === 'add-to-carte') {
        const selectedItem = document.querySelector('input[name="Price"]:checked');
        if (selectedItem) {
            const price = selectedItem.value;
            alert(`You have purchased the item for $${price}`);
        } else {
            alert("Please select an item to purchase.");
        }
    }
});

// Add event listener to the third button
document.addEventListener('click', function(event) {
    if (event.target.id === 'add-to-carts') {
        const selectedItem = document.querySelector('input[name="Price"]:checked');
        if (selectedItem) {
            const price = selectedItem.value;
            alert(`You have purchased the item for $${price}`);
        } else {
            alert("Please select an item to purchase.");
        }
    }
});

// Add event listener to the scroll-up button
document.addEventListener('scroll', function() {
    const scrollUpButton = document.querySelector('.Scroll-up-btn');
    if (window.scrollY > 500) {
        scrollUpButton.classList.add('show');
    } else {
        scrollUpButton.classList.remove('show');
    }
});

// Add event listener to the scroll-up button click
document.addEventListener('click', function(event) {
    if (event.target.classList.contains('Scroll-up-btn')) {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
});

// Add event listener to the login form
document.addEventListener('submit', function(event) {
    if (event.target.id === 'loginForm') {
        event.preventDefault();
        const username = document.querySelector('#username').value;
        const password = document.querySelector('#password').value;
        if (username && password) {
            alert(`You have logged in with username ${username} and password ${password}`);
        } else {
            alert("Please enter a valid username and password.");
        }
    }
});
// Add event listener to the scroll-up button
document.addEventListener('scroll', function() {
    const scrollUpButton = document.querySelector('.Scroll-up-btn');
    if (window.scrollY > 500) {
        scrollUpButton.classList.add('show');
    } else {
        scrollUpButton.classList.remove('show');
    }
});

// Add event listener to the scroll-up button click
document.querySelector('.Scroll-up-btn').addEventListener('click', function() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
});