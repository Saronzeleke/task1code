const themeToggleButton = document.getElementById('theme-toggle');

themeToggleButton.addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');
    
    // Change the icon based on the current theme
    if (document.body.classList.contains('dark-mode')) {
        themeToggleButton.textContent = '☀️'; // Sun icon for light mode
    } else {
        themeToggleButton.textContent = '🌙'; // Moon icon for dark mode
    }
});
$('.menu-btn').click(function(){
    $('.navbar .menu').toggleClass("active");
    $('.menu-btn').toggleClass("active");
});






let cartCounte = 0;

document.getElementById('add-to-carte','carts','cart').onclick = function() {
    const selectedItem = document.querySelector('input[name="Price"]:checked');
    
    if (selectedItem) {
        const price = selectedItem.value;
        alert(`You have purchased the item for $${price}`); // Fixed template literal
        cartCount++; // Increment cart count
        document.getElementById('cart-count').innerText = cartCount; // Update cart count display
    } else {
        alert("Please select an item to purchase.");
    }
};


// Get all products from the backend
