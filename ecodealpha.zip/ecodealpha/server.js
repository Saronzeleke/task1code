// Import required modules
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
// Connect to MongoDB
mongoose.connect('mongodb://localhost/kunas-store')
.then(() => console.log('Connected to MongoDB'))
  .catch(err => console.log(err));

// Define the schema for the products collection
// const productSchema = new mongoose.Schema({
//     name: String,
//     price: Number,
//     description: String
// });
const productSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    description: {
        type: String,
        required: true
    },
    price: {
        type: Number,
        required: true
    },
    imageUrl: {
        type: String,
        required: true
    }
});
const Product = mongoose.model('Product', productSchema);
// const Product = mongoose.model('Product', productSchema);
// module.exports = Product;


const orderSchema = new mongoose.Schema({
    product: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Product',
        required: true
    },
    price: {
        type: Number,
        required: true
    },
    customerName: {
        type: String,
        required: true
    },
    customerEmail: {
        type: String,
        required: true
    },
    dateOrdered: {
        type: Date,
        default: Date.now
    }
});

const Order = mongoose.model('Order', orderSchema);
module.exports = Order;


// Create a model for the products collection


// Create a route to get all products
app.get('/products', async (req, res) => {
    try {
        const products = await Product.find();
        res.json(products);
    } catch (err) {
        res.status(500).json({ message: 'Error fetching products' });
    }
});

// Create a route to add a new product
app.post('/products', async (req, res) => {
    try {
        const product = new Product(req.body);
        await product.save();
        res.json(product);
    } catch (err) {
        res.status(500).json({ message: 'Error adding product' });
    }
});
app.post('/orders', async (req, res) => {
    const { product, price, customerName, customerEmail } = req.body;
    
    try {
        const order = new Order({
            product,
            price,
            customerName,
            customerEmail
        });
        
        await order.save();
        res.json({ message: 'Order placed successfully!' });
    } catch (error) {
        res.status(500).json({ error: 'Error placing order' });
    }
});


// Create a route to update a product
app.put('/products/:id', async (req, res) => {
    try {
        const product = await Product.findByIdAndUpdate(req.params.id, req.body, { new: true });
        res.json(product);
    } catch (err) {
        res.status(500).json({ message: 'Error updating product' });
    }
});

// Create a route to delete a product
app.delete('/products/:id', async (req, res) => {
    try {
        await Product.findByIdAndRemove(req.params.id);
        res.json({ message: 'Product deleted successfully' });
    } catch (err) {
        res.status(500).json({ message: 'Error deleting product' });
    }
});

// Start the server
app.listen(port, () => {
    console.log(`Server started on port ${port}`);
});